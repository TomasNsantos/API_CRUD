//config inicial
const express = require('express');
const mongoose = require('mongoose');
const app = express();

const Person = require('./models/Person')

// forma de ler JSON / middlewares
app.use(
    express.urlencoded({
        extended: true,
    }),
)

app.use(express.json())

//rotas da API
app.post('/person', async (req, res) => {

    //req. body

    // { name: 'Tomas', salary: 1000, approved: true }
    const { name, salary, approved } = req.body

    if(!name) {
        return res.status(422).json({ message: 'O campo nome é obrigatório!' })
    }

    const person = {
        name,
        salary,
        approved,
    }

    try {
        // criando dados
        await Person.create(person)

        res.status(201).json({ message: 'Pessoa inserida no sistema com sucesso!' })
    } catch (error) {
        res.status(500).json({ error: error })
    } 

})

//rota inicial / endpoint
app.get('/', (req, res) => {
    // mostrar req 

    res.json({ message: 'Oi Express!' })
}) 

// 68eoFqBJJccps4w4

// mongodb+srv://tomasnascimentosantos:<68eoFqBJJccps4w4>@apicluster.avdtf7b.mongodb.net/bancodaapi?retryWrites=true&w=majority&appName=APICluster

//entregar uma porta
const DB_USER = 'tomasnascimentosantos'
const DB_PASSWORD = encodeURIComponent('68eoFqBJJccps4w4')


mongoose
    .connect(
        `mongodb+srv://${DB_USER}:${DB_PASSWORD}@apicluster.avdtf7b.mongodb.net/bancodaapi?retryWrites=true&w=majority&appName=APICluster`
    )
    .then(() => {
        console.log('Conectado ao MongoDB!')
        app.listen(3000)
    })
    .catch((err) => { console.log(err) })

app.listen(3000)